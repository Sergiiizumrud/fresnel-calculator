package ua.fresnelcalculator

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import java.util.Locale
import kotlin.math.max
import kotlin.math.min

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { FresnelApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FresnelApp() {
    var frequency by remember { mutableStateOf("2400") }
    var distance by remember { mutableStateOf("10") }
    var point by remember { mutableStateOf("5") }
    var txHeight by remember { mutableStateOf("10") }
    var rxHeight by remember { mutableStateOf("10") }
    var obstacleDistance by remember { mutableStateOf("5") }
    var obstacleHeight by remember { mutableStateOf("2") }

    val values = listOf(frequency, distance, point, txHeight, rxHeight, obstacleDistance, obstacleHeight)
    val parsed = values.map { it.replace(',', '.').toDoubleOrNull() }
    val valid = parsed.all { it != null }
    val f = parsed[0] ?: 0.0
    val d = parsed[1] ?: 0.0
    val p = parsed[2] ?: 0.0
    val tx = parsed[3] ?: 0.0
    val rx = parsed[4] ?: 0.0
    val obsD = parsed[5] ?: 0.0
    val obsH = parsed[6] ?: 0.0

    val fresnel = remember(frequency, distance, point) {
        runCatching { FresnelMath.calculate(f, d, p) }.getOrNull()
    }
    val profile = remember(frequency, distance, txHeight, rxHeight, obstacleDistance, obstacleHeight) {
        runCatching { FresnelMath.profile(f, d, obsD, tx, rx, obsH) }.getOrNull()
    }
    val inputError = when {
        !valid -> "Введіть числові значення в усі поля."
        f <= 0.0 || d <= 0.0 -> "Частота й довжина траси мають бути більшими за нуль."
        p !in 0.0..d -> "Точка розрахунку має бути в межах довжини траси."
        obsD !in 0.0..d -> "Відстань до перешкоди має бути в межах траси."
        tx < 0.0 || rx < 0.0 || obsH < 0.0 -> "Висоти не можуть бути від'ємними."
        else -> null
    }

    MaterialTheme(colorScheme = lightColorScheme()) {
        Scaffold(
            topBar = {
                TopAppBar(title = {
                    Column {
                        Text("Fresnel Calculator", fontWeight = FontWeight.Bold)
                        Text("Версія 0.2.0 • висоти антен і профіль", style = MaterialTheme.typography.labelSmall)
                    }
                })
            }
        ) { padding ->
            Column(
                modifier = Modifier.padding(padding).fillMaxSize()
                    .verticalScroll(rememberScrollState()).padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text("Параметри радіолінії", style = MaterialTheme.typography.titleLarge)
                InputField("Частота, МГц", frequency, { frequency = it })
                InputField("Довжина радіолінії, км", distance, { distance = it })
                InputField("Точка розрахунку зони, км", point, { point = it })

                HorizontalDivider()
                Text("Висоти антен", style = MaterialTheme.typography.titleLarge)
                InputField("Висота передавальної антени над землею, м", txHeight, { txHeight = it })
                InputField("Висота приймальної антени над землею, м", rxHeight, { rxHeight = it })

                HorizontalDivider()
                Text("Контрольна перешкода", style = MaterialTheme.typography.titleLarge)
                InputField("Відстань перешкоди від початку траси, км", obstacleDistance, { obstacleDistance = it })
                InputField("Висота перешкоди над умовною землею, м", obstacleHeight, { obstacleHeight = it })
                Text(
                    "У цій версії профіль умовний: земля між кінцевими точками вважається рівною, а одна перешкода задається вручну.",
                    style = MaterialTheme.typography.bodySmall
                )

                if (inputError != null) {
                    Text(inputError, color = MaterialTheme.colorScheme.error)
                } else {
                    fresnel?.let { r ->
                        ResultCard("Довжина хвилі", "${fmt(r.wavelengthM)} м")
                        ResultCard("Максимальний радіус першої зони", "${fmt(r.maxRadiusM)} м")
                        ResultCard("Радіус зони у вибраній точці", "${fmt(r.radiusAtPointM)} м")
                        ResultCard("60% радіуса у вибраній точці", "${fmt(r.clearance60M)} м")
                    }
                    profile?.let { r ->
                        Text("Оцінка перешкоди", style = MaterialTheme.typography.titleLarge)
                        ResultCard("Висота прямої радіолінії над землею в точці перешкоди", "${fmt(r.lineHeightAtObstacleM)} м")
                        ResultCard("Запас до прямої радіолінії", "${fmt(r.obstacleClearanceM)} м")
                        ResultCard("Запас з урахуванням 60% зони Френеля", "${fmt(r.fresnelMarginM)} м")
                        StatusCard("Пряма видимість", if (r.hasLineOfSight) "Є" else "Немає", r.hasLineOfSight)
                        StatusCard("Очищення 60% зони Френеля", if (r.has60PercentClearance) "Достатнє" else "Недостатнє", r.has60PercentClearance)
                    }
                    Text("Графічний профіль радіотраси", style = MaterialTheme.typography.titleLarge)
                    profile?.let {
                        LinkProfileChart(
                            totalDistanceKm = d,
                            txHeightM = tx,
                            rxHeightM = rx,
                            obstacleDistanceKm = obsD,
                            obstacleHeightM = obsH,
                            frequencyMHz = f
                        )
                        Text("Схема не є топографічним профілем місцевості. Вона показує пряму радіолінію, розрахункову першу зону Френеля та одну задану перешкоду.", style = MaterialTheme.typography.bodySmall)
                    }
                }

                OutlinedButton(onClick = {
                    frequency = "2400"; distance = "10"; point = "5"
                    txHeight = "10"; rxHeight = "10"; obstacleDistance = "5"; obstacleHeight = "2"
                }, modifier = Modifier.fillMaxWidth()) { Text("Скинути до прикладу") }
            }
        }
    }
}

@Composable
private fun InputField(label: String, value: String, onValue: (String) -> Unit) {
    OutlinedTextField(
        value = value,
        onValueChange = onValue,
        label = { Text(label) },
        singleLine = true,
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
        modifier = Modifier.fillMaxWidth()
    )
}

@Composable
private fun ResultCard(label: String, value: String) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp)) {
            Text(label, style = MaterialTheme.typography.bodyMedium)
            Text(value, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
        }
    }
}

@Composable
private fun StatusCard(label: String, value: String, good: Boolean) {
    Card(modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(
        containerColor = if (good) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.errorContainer
    )) {
        Column(Modifier.padding(14.dp)) {
            Text(label, style = MaterialTheme.typography.bodyMedium)
            Text(value, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun LinkProfileChart(
    totalDistanceKm: Double,
    txHeightM: Double,
    rxHeightM: Double,
    obstacleDistanceKm: Double,
    obstacleHeightM: Double,
    frequencyMHz: Double
) {
    val maxFresnel = runCatching { FresnelMath.calculate(frequencyMHz, totalDistanceKm, totalDistanceKm / 2.0).maxRadiusM }.getOrDefault(0.0)
    val yMax = max( max(txHeightM, rxHeightM), max(obstacleHeightM, maxFresnel + max(txHeightM, rxHeightM))) + 3.0
    val yMin = min(0.0, min(txHeightM, rxHeightM))
    Canvas(Modifier.fillMaxWidth().height(250.dp)) {
        val left = 12f
        val right = size.width - 12f
        val top = 12f
        val bottom = size.height - 12f
        val plotW = right - left
        val plotH = bottom - top
        fun x(km: Double) = left + (km / totalDistanceKm).toFloat() * plotW
        fun y(m: Double) = bottom - ((m - yMin) / (yMax - yMin).coerceAtLeast(1.0)).toFloat() * plotH

        for (i in 0..4) {
            val gy = top + plotH * i / 4f
            drawLine(androidx.compose.ui.graphics.Color.LightGray, Offset(left, gy), Offset(right, gy), 1f)
        }
        val groundY = y(0.0)
        drawLine(androidx.compose.ui.graphics.Color.DarkGray, Offset(left, groundY), Offset(right, groundY), 3f)

        val upper = Path()
        val lower = Path()
        val samples = 60
        for (i in 0..samples) {
            val km = totalDistanceKm * i / samples
            val frac = km / totalDistanceKm
            val line = txHeightM + (rxHeightM - txHeightM) * frac
            val radius = FresnelMath.radiusAt(frequencyMHz, totalDistanceKm, km)
            val px = x(km)
            val pyTop = y(line + radius)
            val pyBottom = y(line - radius)
            if (i == 0) { upper.moveTo(px, pyTop); lower.moveTo(px, pyBottom) }
            else { upper.lineTo(px, pyTop); lower.lineTo(px, pyBottom) }
        }
        val zone = Path().apply {
            addPath(upper)
            for (i in samples downTo 0) {
                val km = totalDistanceKm * i / samples
                val frac = km / totalDistanceKm
                val line = txHeightM + (rxHeightM - txHeightM) * frac
                val radius = FresnelMath.radiusAt(frequencyMHz, totalDistanceKm, km)
                lineTo(x(km), y(line - radius))
            }
            close()
        }
        drawPath(zone, androidx.compose.ui.graphics.Color(0x334F83CC))
        drawPath(upper, androidx.compose.ui.graphics.Color(0xFF3976B8), style = Stroke(width = 2f))
        drawPath(lower, androidx.compose.ui.graphics.Color(0xFF3976B8), style = Stroke(width = 2f))

        drawLine(androidx.compose.ui.graphics.Color(0xFF202020), Offset(x(0.0), y(txHeightM)), Offset(x(totalDistanceKm), y(rxHeightM)), 4f)
        val ox = x(obstacleDistanceKm)
        drawLine(androidx.compose.ui.graphics.Color(0xFFD64A38), Offset(ox, groundY), Offset(ox, y(obstacleHeightM)), 8f)
        drawCircle(androidx.compose.ui.graphics.Color(0xFFD64A38), radius = 6f, center = Offset(ox, y(obstacleHeightM)))
        drawCircle(androidx.compose.ui.graphics.Color(0xFF202020), radius = 5f, center = Offset(x(0.0), y(txHeightM)))
        drawCircle(androidx.compose.ui.graphics.Color(0xFF202020), radius = 5f, center = Offset(x(totalDistanceKm), y(rxHeightM)))
    }
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text("0 км", style = MaterialTheme.typography.labelSmall)
        Text("${fmt(totalDistanceKm)} км", style = MaterialTheme.typography.labelSmall)
    }
    Text("Легенда: синя область — 1-ша зона Френеля; темна лінія — радіолінія; червона — перешкода; сіра — умовна земля.", style = MaterialTheme.typography.bodySmall)
}

private fun fmt(value: Double): String = String.format(Locale.US, "%.3f", value)
