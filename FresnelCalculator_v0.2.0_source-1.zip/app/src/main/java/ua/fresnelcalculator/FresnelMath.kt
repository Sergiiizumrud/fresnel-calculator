package ua.fresnelcalculator

import kotlin.math.sqrt

data class FresnelResult(
    val wavelengthM: Double,
    val maxRadiusM: Double,
    val radiusAtPointM: Double,
    val clearance60M: Double,
    val clearance100M: Double
)

data class LinkProfileResult(
    val fresnel: FresnelResult,
    val lineHeightAtObstacleM: Double,
    val obstacleClearanceM: Double,
    val required60HeightM: Double,
    val fresnelMarginM: Double,
    val hasLineOfSight: Boolean,
    val has60PercentClearance: Boolean
)

object FresnelMath {
    /** First Fresnel-zone radius: r = sqrt(lambda * d1 * d2 / (d1 + d2)). */
    fun calculate(frequencyMHz: Double, totalDistanceKm: Double, pointFromStartKm: Double): FresnelResult {
        require(frequencyMHz > 0.0) { "Частота має бути більшою за нуль" }
        require(totalDistanceKm > 0.0) { "Довжина траси має бути більшою за нуль" }
        require(pointFromStartKm in 0.0..totalDistanceKm) { "Точка має бути в межах траси" }

        val wavelength = 299_792_458.0 / (frequencyMHz * 1_000_000.0)
        val totalM = totalDistanceKm * 1000.0
        val d1 = pointFromStartKm * 1000.0
        val d2 = totalM - d1
        val radius = if (d1 == 0.0 || d2 == 0.0) 0.0 else sqrt(wavelength * d1 * d2 / (d1 + d2))
        val maxRadius = sqrt(wavelength * totalM / 4.0)
        return FresnelResult(wavelength, maxRadius, radius, radius * 0.60, radius)
    }

    fun profile(
        frequencyMHz: Double,
        totalDistanceKm: Double,
        obstacleDistanceKm: Double,
        txHeightM: Double,
        rxHeightM: Double,
        obstacleHeightM: Double
    ): LinkProfileResult {
        require(txHeightM >= 0.0 && rxHeightM >= 0.0) { "Висоти антен не можуть бути від'ємними" }
        require(obstacleHeightM >= 0.0) { "Висота перешкоди не може бути від'ємною" }
        val fresnel = calculate(frequencyMHz, totalDistanceKm, obstacleDistanceKm)
        val fraction = obstacleDistanceKm / totalDistanceKm
        val lineHeight = txHeightM + (rxHeightM - txHeightM) * fraction
        val clearance = lineHeight - obstacleHeightM
        val margin = clearance - fresnel.clearance60M
        return LinkProfileResult(
            fresnel = fresnel,
            lineHeightAtObstacleM = lineHeight,
            obstacleClearanceM = clearance,
            required60HeightM = lineHeight - fresnel.clearance60M,
            fresnelMarginM = margin,
            hasLineOfSight = clearance > 0.0,
            has60PercentClearance = margin >= 0.0
        )
    }

    fun radiusAt(frequencyMHz: Double, totalDistanceKm: Double, pointFromStartKm: Double): Double =
        calculate(frequencyMHz, totalDistanceKm, pointFromStartKm).radiusAtPointM
}
