package ua.fresnelcalculator

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import java.util.Locale

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { FresnelApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FresnelApp() {
    var frequency by remember { mutableStateOf("2400") }
    var distance by remember { mutableStateOf("10") }
    var point by remember { mutableStateOf("5") }
    var error by remember { mutableStateOf<String?>(null) }

    val result = remember(frequency, distance, point) {
        runCatching {
            FresnelMath.calculate(
                frequency.toDouble(),
                distance.toDouble(),
                point.toDouble()
            )
        }.onFailure { error = it.message }
            .getOrNull()
    }

    MaterialTheme(colorScheme = lightColorScheme()) {
        Scaffold(
            topBar = {
                TopAppBar(title = {
                    Column {
                        Text("Fresnel Calculator", fontWeight = FontWeight.Bold)
                        Text("Версія 0.1.0 • перша робоча основа", style = MaterialTheme.typography.labelSmall)
                    }
                })
            }
        ) { padding ->
            Column(
                modifier = Modifier.padding(padding).fillMaxSize()
                    .verticalScroll(rememberScrollState()).padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Text("Розрахунок першої зони Френеля", style = MaterialTheme.typography.titleLarge)
                InputField("Частота, МГц", frequency, { frequency = it }, "2400")
                InputField("Довжина радіолінії, км", distance, { distance = it }, "10")
                InputField("Відстань від початку траси, км", point, { point = it }, "5")

                result?.let { r ->
                    ResultCard("Довжина хвилі", fmt(r.wavelengthM) + " м")
                    ResultCard("Максимальний радіус зони (середина траси)", fmt(r.maxRadiusM) + " м")
                    ResultCard("Радіус зони в заданій точці", fmt(r.radiusAtPointM) + " м")
                    ResultCard("60% радіуса — орієнтир очищення", fmt(r.clearance60M) + " м")
                    ResultCard("100% радіуса", fmt(r.clearance100M) + " м")
                    Text(
                        "Примітка: це геометричний розрахунок першої зони Френеля. Він не враховує рельєф, кривизну Землі, рефракцію та фактичні перешкоди.",
                        style = MaterialTheme.typography.bodySmall
                    )
                } ?: Text(error ?: "Перевірте введені значення.", color = MaterialTheme.colorScheme.error)

                OutlinedButton(onClick = {
                    frequency = "2400"; distance = "10"; point = "5"; error = null
                }, modifier = Modifier.fillMaxWidth()) {
                    Text("Скинути до прикладу")
                }
                Text("Наступний етап: профіль траси, висоти антен, рельєф і метеодані.",
                    style = MaterialTheme.typography.bodyMedium)
            }
        }
    }
}

@Composable
private fun InputField(label: String, value: String, onValue: (String) -> Unit, hint: String) {
    OutlinedTextField(
        value = value,
        onValueChange = onValue,
        label = { Text(label) },
        placeholder = { Text(hint) },
        singleLine = true,
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
        modifier = Modifier.fillMaxWidth()
    )
}

@Composable
private fun ResultCard(label: String, value: String) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp)) {
            Text(label, style = MaterialTheme.typography.bodyMedium)
            Text(value, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
        }
    }
}

private fun fmt(value: Double): String = String.format(Locale.US, "%.3f", value)
