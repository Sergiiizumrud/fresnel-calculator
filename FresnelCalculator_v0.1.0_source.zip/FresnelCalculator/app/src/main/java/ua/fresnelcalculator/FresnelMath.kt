package ua.fresnelcalculator

import kotlin.math.sqrt

data class FresnelResult(
    val wavelengthM: Double,
    val maxRadiusM: Double,
    val radiusAtPointM: Double,
    val clearance60M: Double,
    val clearance100M: Double
)

object FresnelMath {
    /**
     * First Fresnel-zone radius:
     * r = sqrt(lambda * d1 * d2 / (d1 + d2))
     * Distances are metres; frequency is MHz.
     */
    fun calculate(frequencyMHz: Double, totalDistanceKm: Double, pointFromStartKm: Double): FresnelResult {
        require(frequencyMHz > 0.0) { "Frequency must be positive" }
        require(totalDistanceKm > 0.0) { "Path length must be positive" }
        require(pointFromStartKm in 0.0..totalDistanceKm) { "Point must lie on the path" }

        val frequencyHz = frequencyMHz * 1_000_000.0
        val wavelength = 299_792_458.0 / frequencyHz
        val totalM = totalDistanceKm * 1000.0
        val d1 = pointFromStartKm * 1000.0
        val d2 = totalM - d1

        val radiusAtPoint = if (d1 == 0.0 || d2 == 0.0) 0.0
            else sqrt(wavelength * d1 * d2 / (d1 + d2))
        val maxRadius = sqrt(wavelength * totalM / 4.0)

        return FresnelResult(
            wavelengthM = wavelength,
            maxRadiusM = maxRadius,
            radiusAtPointM = radiusAtPoint,
            clearance60M = radiusAtPoint * 0.60,
            clearance100M = radiusAtPoint
        )
    }
}
